import os
import secrets
import logging
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("free-fire-like-api")

APP_NAME = "Free Fire Like API (IND)"
API_KEY = os.getenv("API_KEY", "")
MAX_UID_LENGTH = 32

app = FastAPI(
    title=APP_NAME,
    description=(
        "A safe FastAPI starter for India-region Free Fire like requests. "
        "It does not fabricate likes or connect to unofficial game endpoints. "
        "Configure an authorized upstream provider before enabling real likes."
    ),
    version="1.0.0",
)


class LikeRequest(BaseModel):
    uid: str = Field(..., min_length=1, max_length=MAX_UID_LENGTH, pattern=r"^[0-9]+$")
    region: str = Field(default="IND", pattern=r"^IND$")


class ErrorResponse(BaseModel):
    detail: str


def require_api_key(x_api_key: Optional[str] = Header(default=None)):
    if not API_KEY:
        # Prevent accidentally exposing a production endpoint without auth.
        raise HTTPException(
            status_code=503,
            detail="API is not configured. Set API_KEY in the .env file.",
        )
    if not x_api_key or not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Missing or invalid API key.")
    return True


@app.get("/")
def root():
    return {
        "name": APP_NAME,
        "status": "online",
        "region": "IND",
        "docs": "/docs",
        "note": "Real like delivery requires a configured, authorized upstream provider.",
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/v1/likes")
def send_likes(payload: LikeRequest, _auth: bool = Depends(require_api_key)):
    """
    Safe starter endpoint. Does not claim to send likes until an authorized
    upstream provider is integrated. Set UPSTREAM_LIKE_URL only for a provider
    you are authorized to use, then implement its documented request/response.
    """
    upstream_url = os.getenv("UPSTREAM_LIKE_URL", "").strip()
    if not upstream_url:
        raise HTTPException(
            status_code=501,
            detail=(
                "Like provider is not configured. Add an authorized provider's "
                "documented endpoint and integration before real likes can be sent."
            ),
        )

    # Intentionally fail closed rather than guessing a third-party API contract.
    # Integrate only according to the provider's official documentation.
    logger.warning("Authorized upstream URL configured, but adapter is not implemented.")
    raise HTTPException(
        status_code=501,
        detail=(
            "Upstream endpoint is configured, but its documented adapter is not "
            "implemented. No likes were sent."
        ),
    )


@app.get("/api/v1/likes/{uid}")
def like_status(uid: str, _auth: bool = Depends(require_api_key)):
    if not uid.isdigit() or not (1 <= len(uid) <= MAX_UID_LENGTH):
        raise HTTPException(status_code=422, detail="UID must contain 1–32 digits.")
    raise HTTPException(
        status_code=501,
        detail="Like status requires an authorized provider integration.",
    )


@app.exception_handler(Exception)
async def unexpected_error_handler(request, exc):
    logger.exception("Unhandled error on %s", request.url.path)
    from fastapi.responses import JSONResponse
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Check server logs for details."},
    )
