# Free Fire Like API — India (IND)

A ZIP-ready FastAPI starter with authentication, validation, health checks, and clear HTTP status codes.

## Important limitation

This project is a backend scaffold, **not a working like injector**. Real likes require an authorized provider/API and its official documentation. The code deliberately does not invent endpoints, spoof game requests, or claim that likes were delivered. Until a documented provider adapter is implemented, the like endpoint returns `501 Not Implemented`.

## Run locally

1. Install Python 3.10+.
2. Create a virtual environment (recommended).
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Copy `.env.example` to `.env`.
5. Replace `API_KEY` with a long random secret.
6. Start the server:

   ```bash
   uvicorn app.main:app --host 127.0.0.1 --port 8000
   ```

7. Open `http://127.0.0.1:8000/docs`.

## Endpoints

- `GET /` — API information
- `GET /health` — health check
- `POST /api/v1/likes` — validated request; requires `X-API-Key`
- `GET /api/v1/likes/{uid}` — status placeholder; requires `X-API-Key`

Example request:

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/likes" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: replace_with_a_long_random_secret" \
  -d '{"uid":"123456789","region":"IND"}'
```

Expected response until an authorized provider adapter is integrated: HTTP `501`.

## Status codes

- `200` success / health check
- `401` missing or invalid API key
- `422` invalid UID or request body
- `500` unexpected internal error
- `501` provider integration not implemented
- `503` API key configuration missing

## Production notes

- Do not commit `.env` or share your API key.
- Deploy behind HTTPS and a reverse proxy.
- Add rate limiting and monitoring before public exposure.
- Only integrate an upstream service you are authorized to use, following its published API contract.
